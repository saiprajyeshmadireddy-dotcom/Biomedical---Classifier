# Dataset notes

The project has used the MIT-BIH heartbeat dataset obtained via Kaggle:
https://www.kaggle.com/datasets/shayanfazeli/heartbeat

Before submission, the team should verify and record:
- the exact version/date downloaded;
- the dataset's license and permitted uses;
- any attribution or redistribution requirements;
- whether hackathon rules allow the raw data to be committed to the public repository.

This file is documentation only. It does **not** assert that the license has been independently verified. Prefer keeping raw CSV data out of the public GitHub repository unless redistribution is clearly permitted and needed.
